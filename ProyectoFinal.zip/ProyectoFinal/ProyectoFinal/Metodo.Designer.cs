﻿namespace ProyectoFinal
{
    partial class Metodo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_1 = new System.Windows.Forms.Label();
            this.txt_Margen = new System.Windows.Forms.TextBox();
            this.lbl2 = new System.Windows.Forms.Label();
            this.OP_FIFO = new System.Windows.Forms.RadioButton();
            this.OP_LIFO = new System.Windows.Forms.RadioButton();
            this.OP_PPP = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_LFP = new System.Windows.Forms.Button();
            this.cmb_Todos = new System.Windows.Forms.ComboBox();
            this.lbl_prod = new System.Windows.Forms.Label();
            this.lbl_cant = new System.Windows.Forms.Label();
            this.cmb_Cant = new System.Windows.Forms.ComboBox();
            this.lbl_FIFO = new System.Windows.Forms.Label();
            this.lbl_LIFO = new System.Windows.Forms.Label();
            this.lbl_PPP = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_1
            // 
            this.lbl_1.AutoSize = true;
            this.lbl_1.Location = new System.Drawing.Point(28, 81);
            this.lbl_1.Name = "lbl_1";
            this.lbl_1.Size = new System.Drawing.Size(177, 17);
            this.lbl_1.TabIndex = 0;
            this.lbl_1.Text = "Indique Margen de Utilidad";
            // 
            // txt_Margen
            // 
            this.txt_Margen.Location = new System.Drawing.Point(31, 114);
            this.txt_Margen.Name = "txt_Margen";
            this.txt_Margen.Size = new System.Drawing.Size(74, 22);
            this.txt_Margen.TabIndex = 1;
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(120, 117);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(20, 17);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "%";
            // 
            // OP_FIFO
            // 
            this.OP_FIFO.AutoSize = true;
            this.OP_FIFO.Location = new System.Drawing.Point(19, 36);
            this.OP_FIFO.Name = "OP_FIFO";
            this.OP_FIFO.Size = new System.Drawing.Size(59, 21);
            this.OP_FIFO.TabIndex = 4;
            this.OP_FIFO.TabStop = true;
            this.OP_FIFO.Text = "FIFO";
            this.OP_FIFO.UseVisualStyleBackColor = true;
            // 
            // OP_LIFO
            // 
            this.OP_LIFO.AutoSize = true;
            this.OP_LIFO.Location = new System.Drawing.Point(19, 73);
            this.OP_LIFO.Name = "OP_LIFO";
            this.OP_LIFO.Size = new System.Drawing.Size(59, 21);
            this.OP_LIFO.TabIndex = 5;
            this.OP_LIFO.TabStop = true;
            this.OP_LIFO.Text = "LIFO";
            this.OP_LIFO.UseVisualStyleBackColor = true;
            // 
            // OP_PPP
            // 
            this.OP_PPP.AutoSize = true;
            this.OP_PPP.Location = new System.Drawing.Point(19, 110);
            this.OP_PPP.Name = "OP_PPP";
            this.OP_PPP.Size = new System.Drawing.Size(56, 21);
            this.OP_PPP.TabIndex = 6;
            this.OP_PPP.TabStop = true;
            this.OP_PPP.Text = "PPP";
            this.OP_PPP.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.lbl_PPP);
            this.groupBox1.Controls.Add(this.lbl_LIFO);
            this.groupBox1.Controls.Add(this.lbl_FIFO);
            this.groupBox1.Controls.Add(this.OP_PPP);
            this.groupBox1.Controls.Add(this.OP_LIFO);
            this.groupBox1.Controls.Add(this.OP_FIFO);
            this.groupBox1.Location = new System.Drawing.Point(12, 156);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(198, 137);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Indique Metodo de Costeo";
            // 
            // btn_LFP
            // 
            this.btn_LFP.Location = new System.Drawing.Point(263, 279);
            this.btn_LFP.Name = "btn_LFP";
            this.btn_LFP.Size = new System.Drawing.Size(126, 38);
            this.btn_LFP.TabIndex = 8;
            this.btn_LFP.Text = "Aceptar";
            this.btn_LFP.UseVisualStyleBackColor = true;
            // 
            // cmb_Todos
            // 
            this.cmb_Todos.FormattingEnabled = true;
            this.cmb_Todos.Location = new System.Drawing.Point(31, 38);
            this.cmb_Todos.Name = "cmb_Todos";
            this.cmb_Todos.Size = new System.Drawing.Size(179, 24);
            this.cmb_Todos.TabIndex = 9;
            // 
            // lbl_prod
            // 
            this.lbl_prod.AutoSize = true;
            this.lbl_prod.Location = new System.Drawing.Point(28, 18);
            this.lbl_prod.Name = "lbl_prod";
            this.lbl_prod.Size = new System.Drawing.Size(99, 17);
            this.lbl_prod.TabIndex = 10;
            this.lbl_prod.Text = "Elija Producto ";
            // 
            // lbl_cant
            // 
            this.lbl_cant.AutoSize = true;
            this.lbl_cant.Location = new System.Drawing.Point(247, 18);
            this.lbl_cant.Name = "lbl_cant";
            this.lbl_cant.Size = new System.Drawing.Size(126, 17);
            this.lbl_cant.TabIndex = 11;
            this.lbl_cant.Text = "Indique Cantidad : ";
            // 
            // cmb_Cant
            // 
            this.cmb_Cant.FormattingEnabled = true;
            this.cmb_Cant.Location = new System.Drawing.Point(263, 38);
            this.cmb_Cant.Name = "cmb_Cant";
            this.cmb_Cant.Size = new System.Drawing.Size(82, 24);
            this.cmb_Cant.TabIndex = 12;
            // 
            // lbl_FIFO
            // 
            this.lbl_FIFO.AutoSize = true;
            this.lbl_FIFO.Location = new System.Drawing.Point(132, 40);
            this.lbl_FIFO.Name = "lbl_FIFO";
            this.lbl_FIFO.Size = new System.Drawing.Size(44, 17);
            this.lbl_FIFO.TabIndex = 13;
            this.lbl_FIFO.Text = "00.00";
            // 
            // lbl_LIFO
            // 
            this.lbl_LIFO.AutoSize = true;
            this.lbl_LIFO.Location = new System.Drawing.Point(132, 73);
            this.lbl_LIFO.Name = "lbl_LIFO";
            this.lbl_LIFO.Size = new System.Drawing.Size(44, 17);
            this.lbl_LIFO.TabIndex = 14;
            this.lbl_LIFO.Text = "00.00";
            // 
            // lbl_PPP
            // 
            this.lbl_PPP.AutoSize = true;
            this.lbl_PPP.Location = new System.Drawing.Point(132, 110);
            this.lbl_PPP.Name = "lbl_PPP";
            this.lbl_PPP.Size = new System.Drawing.Size(44, 17);
            this.lbl_PPP.TabIndex = 15;
            this.lbl_PPP.Text = "00.00";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(112, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 17);
            this.label1.TabIndex = 13;
            this.label1.Text = "$";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(112, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 17);
            this.label2.TabIndex = 14;
            this.label2.Text = "$";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(112, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(16, 17);
            this.label3.TabIndex = 15;
            this.label3.Text = "$";
            // 
            // Metodo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(401, 338);
            this.Controls.Add(this.cmb_Cant);
            this.Controls.Add(this.lbl_cant);
            this.Controls.Add(this.lbl_prod);
            this.Controls.Add(this.cmb_Todos);
            this.Controls.Add(this.btn_LFP);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.txt_Margen);
            this.Controls.Add(this.lbl_1);
            this.Name = "Metodo";
            this.Text = "Metodo";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_1;
        private System.Windows.Forms.TextBox txt_Margen;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.RadioButton OP_FIFO;
        private System.Windows.Forms.RadioButton OP_LIFO;
        private System.Windows.Forms.RadioButton OP_PPP;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_LFP;
        private System.Windows.Forms.ComboBox cmb_Todos;
        private System.Windows.Forms.Label lbl_prod;
        private System.Windows.Forms.Label lbl_cant;
        private System.Windows.Forms.ComboBox cmb_Cant;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_PPP;
        private System.Windows.Forms.Label lbl_LIFO;
        private System.Windows.Forms.Label lbl_FIFO;
    }
}